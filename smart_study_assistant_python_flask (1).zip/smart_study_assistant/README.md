# Smart Study Assistant — Python/Flask + AWS

A web application for BTech students to upload PDF notes and receive:
- An AI-generated concise summary
- 10 multiple-choice quiz questions

---

## System Design

```
User Browser
    │
    │  HTTP Request (upload PDF)
    ▼
Flask Web App (app.py)
    │                    │
    │ upload_to_s3()      │ extract_text_from_pdf()
    ▼                    ▼
Amazon S3           pdfplumber
(PDF storage)       (text extraction)
                         │
                         │ extracted text
                         ▼
                   Amazon Bedrock / OpenAI
                   (Claude / GPT-4o-mini)
                         │
                    ┌────┴────┐
                    ▼         ▼
                Summary    10 Quiz Questions
                    └────┬────┘
                         │
                         ▼
                     SQLite DB
                   (or Amazon RDS)
```

## AWS Architecture

```
                     ┌──────────────────┐
                     │   User Browser   │
                     └────────┬─────────┘
                              │ HTTPS
                     ┌────────▼─────────┐
                     │   Amazon EC2     │
                     │   (Flask app)    │
                     │   + Gunicorn     │
                     └────────┬─────────┘
                    ┌─────────┼─────────┐
                    │         │         │
           ┌────────▼──┐ ┌────▼────┐ ┌─▼────────────┐
           │ Amazon S3 │ │ Amazon  │ │   Amazon RDS  │
           │ (PDF files│ │ Bedrock │ │ (PostgreSQL)  │
           │  storage) │ │ (AI/LLM)│ │ (production   │
           └───────────┘ └─────────┘ │  database)    │
                                     └───────────────┘

Optional async flow with Lambda:
   Flask → S3 upload → invoke Lambda (async) → Lambda processes PDF →
   Lambda calls Bedrock → Lambda updates RDS → Frontend polls for status
```

## Project Folder Structure

```
smart_study_assistant/
├── app.py              ← Main Flask application (routes, request handling)
├── config.py           ← All configuration (AWS, DB, secrets via env vars)
├── aws_services.py     ← S3 upload, Bedrock AI calls, Lambda invocation
├── pdf_processor.py    ← PDF text extraction using pdfplumber
├── database.py         ← SQLite CRUD operations (swap for RDS in prod)
├── requirements.txt    ← Python package list
├── README.md           ← This file
├── .env.example        ← Template for your environment variables
├── templates/
│   ├── base.html       ← Shared layout (navbar, footer, flash messages)
│   ├── index.html      ← Dashboard (document list + stats)
│   ├── upload.html     ← PDF upload form with drag-and-drop
│   └── document.html   ← Summary tab + interactive quiz tab
└── static/
    ├── css/style.css   ← Custom styles (Bootstrap 5 is loaded from CDN)
    └── js/main.js      ← Shared JavaScript
```

---

## Local Setup (Step-by-Step)

### Step 1: Prerequisites

```bash
# Check Python version (need 3.10+)
python --version

# Check pip
pip --version
```

### Step 2: Clone and set up virtual environment

```bash
git clone https://github.com/YOUR_USERNAME/smart-study-assistant.git
cd smart-study-assistant/smart_study_assistant

# Create a virtual environment (isolates packages from system Python)
python -m venv venv

# Activate it
source venv/bin/activate        # Mac/Linux
# OR
venv\Scripts\activate           # Windows
```

### Step 3: Install dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Set environment variables

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
# Edit .env with your text editor
```

```env
# .env file
SECRET_KEY=your-random-secret-key-here
OPENAI_API_KEY=sk-...         # Your OpenAI key (for easy start)
AI_PROVIDER=openai            # or "bedrock" if you have AWS configured

# Optional AWS settings (for S3 + Bedrock)
# AWS_REGION=us-east-1
# S3_BUCKET_NAME=your-bucket-name
# AWS_ACCESS_KEY_ID=AKIA...
# AWS_SECRET_ACCESS_KEY=...
```

### Step 5: Run the app

```bash
# Load environment variables from .env
source .env    # or: export $(cat .env | xargs)

# Run Flask in development mode
python app.py
```

Visit: http://localhost:5000

---

## AWS Setup (Production)

### Step 1: Create S3 Bucket

```bash
aws s3 mb s3://smart-study-assistant-pdfs --region us-east-1

# Block all public access (keep PDFs private)
aws s3api put-public-access-block \
  --bucket smart-study-assistant-pdfs \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
```

### Step 2: Enable Amazon Bedrock

1. Go to AWS Console → Amazon Bedrock
2. Click "Model access" in the left sidebar
3. Request access to: **Anthropic Claude 3 Haiku**
4. Wait for approval (usually instant for Haiku)
5. Set `AI_PROVIDER=bedrock` in your environment

### Step 3: Set IAM Permissions

Your EC2 instance or IAM user needs these permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
      "Resource": "arn:aws:s3:::smart-study-assistant-pdfs/*"
    },
    {
      "Effect": "Allow",
      "Action": ["bedrock:InvokeModel"],
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0"
    }
  ]
}
```

### Step 4: Deploy to EC2

```bash
# On your EC2 instance (Amazon Linux 2 or Ubuntu)
sudo yum install python3 python3-pip git -y   # Amazon Linux
# OR
sudo apt install python3 python3-pip git -y   # Ubuntu

git clone https://github.com/YOUR_USERNAME/smart-study-assistant.git
cd smart-study-assistant/smart_study_assistant
pip3 install -r requirements.txt

# Run with Gunicorn (production WSGI server)
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

---

## Database Design

### Table: documents
| Column        | Type    | Description                          |
|---------------|---------|--------------------------------------|
| id            | INTEGER | Primary key, auto-increment          |
| filename      | TEXT    | Stored filename (UUID + original)    |
| original_name | TEXT    | User-visible filename                |
| s3_url        | TEXT    | S3 URL where PDF is stored           |
| status        | TEXT    | pending / processing / done / error  |
| page_count    | INTEGER | Number of PDF pages                  |
| summary       | TEXT    | AI-generated summary text            |
| extracted_text| TEXT    | Raw text extracted from PDF          |
| created_at    | TEXT    | ISO timestamp                        |

### Table: quiz_questions
| Column        | Type    | Description                          |
|---------------|---------|--------------------------------------|
| id            | INTEGER | Primary key                          |
| document_id   | INTEGER | Foreign key → documents.id           |
| question      | TEXT    | The question text                    |
| option_a/b/c/d| TEXT    | Four answer options                  |
| correct_index | INTEGER | 0=A, 1=B, 2=C, 3=D                  |
| explanation   | TEXT    | Why the answer is correct            |
| order_index   | INTEGER | Display order                        |

### Table: quiz_attempts
| Column        | Type    | Description                          |
|---------------|---------|--------------------------------------|
| id            | INTEGER | Primary key                          |
| document_id   | INTEGER | Foreign key → documents.id           |
| question_id   | INTEGER | Foreign key → quiz_questions.id      |
| selected_index| INTEGER | Which option the user chose          |
| is_correct    | INTEGER | 1 = correct, 0 = wrong               |
| answered_at   | TEXT    | When the user answered               |

---

## Interview Questions & Answers

**Q1: What is Amazon S3 and why did you use it?**
A: S3 (Simple Storage Service) is AWS's object storage — like a hard drive in the cloud. I used it to store uploaded PDFs durably and cost-effectively (~$0.023/GB/month). It's also accessible to AWS Lambda for async processing, and can serve files globally via CloudFront CDN.

**Q2: What is Amazon Bedrock?**
A: Bedrock is AWS's managed AI service that provides access to foundation models (Claude, Titan, Llama) via API without managing any ML infrastructure. You pay per token consumed, making it cost-effective for inference.

**Q3: What is the difference between synchronous and asynchronous processing?**
A: Synchronous: Flask waits for the AI to finish before responding (simple, but user waits 30-60s). Asynchronous: Flask returns immediately, Lambda processes the PDF in the background, frontend polls for status. Async is better UX for long-running tasks.

**Q4: Why use environment variables for secrets?**
A: Hardcoding secrets in code risks them being committed to Git and exposed. Environment variables are set on the server/machine and not stored in code. Services like AWS Secrets Manager can manage them in production.

**Q5: How does Flask handle file uploads?**
A: Forms need `enctype="multipart/form-data"`. Flask's `request.files["field_name"]` receives the file. We use `werkzeug.utils.secure_filename()` to sanitize the filename and prevent path traversal attacks.

**Q6: What is the difference between SQLite and Amazon RDS?**
A: SQLite is a file-based serverless database — perfect for development but limited to one concurrent writer. Amazon RDS is a managed cloud PostgreSQL/MySQL service that handles thousands of concurrent users, automatic backups, scaling, and patching.

**Q7: What is prompt engineering?**
A: The practice of crafting AI prompts to get reliable, structured outputs. For this project, I specify a JSON schema in the quiz prompt so the response is parseable. I also limit to ~4000 words to control token costs.

---

## Resume Bullet Points

- Built a full-stack AI study tool using **Python/Flask** that extracts text from uploaded PDFs and generates summaries and 10 MCQ quiz questions using **OpenAI GPT-4o-mini / Amazon Bedrock** (Claude Haiku)
- Integrated **Amazon S3** for durable PDF storage and **Amazon Bedrock** for serverless AI inference, reducing infrastructure management overhead
- Designed a 3-table **SQLite/PostgreSQL** schema to track documents, quiz questions, and attempt history; implemented REST API endpoints for quiz answer submission and scoring
- Implemented async PDF processing pattern using **AWS Lambda** (fire-and-forget) with frontend polling, improving perceived performance for 30-60 second AI processing tasks
- Applied security best practices: parameterized SQL queries (prevent injection), `secure_filename()` (prevent path traversal), environment variables for secrets (never hardcoded)

---

## Possible Future Enhancements

1. **Amazon Textract** — Handle scanned/image PDFs using AWS OCR service
2. **Amazon DynamoDB** — NoSQL alternative for storing quiz attempts at scale
3. **AWS Cognito** — User authentication and per-user document isolation
4. **Amazon CloudFront** — CDN for faster static file delivery globally
5. **Flashcard mode** — Generate Anki-style flashcards in addition to quizzes
6. **Progress tracking** — Track quiz performance over time with charts
7. **Multi-language support** — Amazon Translate for non-English notes
8. **Voice Q&A** — Amazon Polly to read questions/answers aloud
9. **Collaborative notes** — Multiple students share a document
10. **Scheduled reminders** — Amazon SES emails spaced-repetition reminders

---

## Git & GitHub Workflow

```bash
# Initialize repo
git init
git add .
git commit -m "Initial commit: Smart Study Assistant"

# Create repo on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/smart-study-assistant.git
git branch -M main
git push -u origin main

# Development workflow
git checkout -b feature/add-flashcards   # New branch for each feature
# ... make changes ...
git add .
git commit -m "feat: add flashcard generation"
git push origin feature/add-flashcards
# Create Pull Request on GitHub
```

**IMPORTANT: Add `.gitignore`** to avoid committing secrets:
```
.env
*.db
venv/
__pycache__/
*.pyc
/tmp/
```
