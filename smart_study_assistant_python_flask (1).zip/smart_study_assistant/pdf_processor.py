"""
PDF Processor Module
====================
CONCEPT: Extract raw text from PDF files so we can send it to AI.

WHY WE NEED THIS:
PDF is a display format, not a text format. A PDF file contains instructions
for how to render a page visually — fonts, positions, images. It doesn't
store text like a .txt file does.

To get the words out, we need a library that understands the PDF format.

LIBRARIES COMPARED:
  pdfplumber  ← We use this. Clean API, handles tables well, maintained.
  PyPDF2      ← Older, less accurate for complex layouts.
  pdfminer    ← Low-level, more control but verbose API.
  pdf2image   ← For image-based PDFs (needs OCR via Tesseract).

LIMITATION — SCANNED PDFs:
If a PDF is created by scanning a physical document, it's just images.
pdfplumber can't read images, so text extraction fails.
For scanned PDFs, you'd need Amazon Textract (OCR service) or pytesseract.

AMAZON TEXTRACT (not implemented here, but mentioned for learning):
  textract_client = boto3.client("textract")
  response = textract_client.detect_document_text(
      Document={"S3Object": {"Bucket": bucket, "Name": key}}
  )
  # Parse response["Blocks"] to get text
"""

import pdfplumber


def extract_text_from_pdf(file_path: str) -> str:
    """
    Extract all text from a PDF file.
    
    HOW pdfplumber WORKS:
    1. Opens the PDF file
    2. Iterates over each page
    3. For each page, extracts text with position info
    4. Joins all text into one string
    
    WHAT WE DO WITH THE TEXT:
    - Send ~4000 words to OpenAI/Bedrock for summarization
    - The AI generates a plain-English summary
    - Same text is used to generate 10 quiz questions
    
    Args:
        file_path: Local path to the PDF file (e.g. /tmp/notes.pdf)
    
    Returns:
        Extracted text as a single string.
        Returns empty string if extraction fails.
    
    Example:
        text = extract_text_from_pdf("/tmp/lecture_notes.pdf")
        print(text[:200])
        # "Chapter 1: Introduction to Cloud Computing
        #  Cloud computing is the delivery of computing services..."
    """
    all_text = []
    page_count = 0

    try:
        # pdfplumber.open() returns a context manager (auto-closes the file)
        # "with" statement ensures file is closed even if an error occurs
        with pdfplumber.open(file_path) as pdf:
            page_count = len(pdf.pages)

            for page_number, page in enumerate(pdf.pages, start=1):
                # page.extract_text() returns text from one page
                # or None if the page has no extractable text
                text = page.extract_text()

                if text:
                    # Add a page marker so the AI knows page boundaries
                    all_text.append(f"\n--- Page {page_number} ---\n{text}")

        # Join all pages into one big string
        full_text = "\n".join(all_text).strip()

        if not full_text:
            print(f"[PDF] No text extracted from {file_path}. May be a scanned PDF.")
            return ""

        print(f"[PDF] Extracted {len(full_text)} characters from {page_count} pages")
        return full_text

    except Exception as e:
        print(f"[PDF] Error extracting text from {file_path}: {e}")
        raise RuntimeError(f"PDF extraction failed: {str(e)}") from e


def get_page_count(file_path: str) -> int:
    """
    Return the number of pages in a PDF.
    
    Args:
        file_path: Path to PDF file
    
    Returns:
        Number of pages (0 if file can't be read)
    """
    try:
        with pdfplumber.open(file_path) as pdf:
            return len(pdf.pages)
    except Exception:
        return 0
