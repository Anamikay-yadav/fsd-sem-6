"""
AWS Services Module
===================
CONCEPT: This file wraps all AWS API calls in clean Python functions.
The rest of the app just calls these functions — it doesn't need to know
how S3 or Bedrock work internally.

This pattern is called the "Service Layer" or "Adapter Pattern".

AWS SERVICES USED:
  1. Amazon S3 (Simple Storage Service)
     - Object storage — like a hard drive in the cloud
     - Used to store uploaded PDFs durably
     - Files stored as "objects" inside "buckets"
     - URL format: s3://bucket-name/path/to/file.pdf

  2. Amazon Bedrock
     - Managed AI/ML service
     - Provides access to Claude (Anthropic), Titan (Amazon), Llama (Meta)
     - We send text → it returns summary/quiz as text
     - Priced per token (roughly per word) consumed

  3. AWS Lambda (optional — shown as a pattern)
     - Serverless compute — runs code without managing servers
     - Ideal for async PDF processing that might take 30-60 seconds
     - AWS starts a container, runs your function, charges per millisecond

BOTO3: The official AWS SDK for Python
  import boto3
  client = boto3.client("s3")  ← creates an S3 API client
  
  boto3 automatically reads credentials from:
    1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    2. ~/.aws/credentials file (set up via `aws configure`)
    3. IAM role attached to EC2/Lambda (best for production)
"""

import json
import boto3
from botocore.exceptions import ClientError, BotoCoreError

from config import Config


# ─────────────────────────────────────────────────────────────────────────────
# Amazon S3 Functions
# ─────────────────────────────────────────────────────────────────────────────

def upload_to_s3(local_file_path: str, s3_key: str) -> str:
    """
    Upload a local file to Amazon S3.
    
    WHAT IS S3?
    Amazon S3 is like a giant hard drive in the cloud.
    - A "bucket" is like a folder at the top level
    - An "object" is a file stored in that bucket
    - Each object has a "key" which is its path/name
    
    EXAMPLE:
        Bucket: my-study-app
        Key:    uploads/abc123_notes.pdf
        URL:    https://my-study-app.s3.amazonaws.com/uploads/abc123_notes.pdf

    Args:
        local_file_path: Path to the file on this server (e.g. /tmp/notes.pdf)
        s3_key: Destination path in S3 (e.g. uploads/notes.pdf)
    
    Returns:
        S3 URL string if successful, empty string if S3 is not configured
    
    COST: S3 storage is ~$0.023 per GB/month. Very cheap for PDFs.
    """
    if not Config.S3_BUCKET_NAME or Config.S3_BUCKET_NAME == "smart-study-assistant-pdfs":
        # S3 not configured — skip upload (works locally without AWS)
        print(f"[S3] Skipping upload — S3_BUCKET_NAME not configured. File: {local_file_path}")
        return f"local://{local_file_path}"

    try:
        # Create an S3 client using boto3
        # boto3.client() automatically uses AWS credentials from environment
        s3_client = boto3.client("s3", region_name=Config.AWS_REGION)

        # upload_file() streams the file directly to S3
        # ExtraArgs sets metadata on the object
        s3_client.upload_file(
            local_file_path,         # Local source file
            Config.S3_BUCKET_NAME,   # Destination bucket
            s3_key,                  # Destination path/key
            ExtraArgs={
                "ContentType": "application/pdf",
                # "ACL": "private"   ← Keep files private (default)
            }
        )

        # Build the S3 URL
        s3_url = f"https://{Config.S3_BUCKET_NAME}.s3.{Config.AWS_REGION}.amazonaws.com/{s3_key}"
        print(f"[S3] Uploaded to: {s3_url}")
        return s3_url

    except ClientError as e:
        # ClientError: AWS rejected the request (wrong credentials, bucket doesn't exist, etc.)
        error_code = e.response["Error"]["Code"]
        print(f"[S3] Upload failed — ClientError {error_code}: {e}")
        raise RuntimeError(f"S3 upload failed: {error_code}") from e

    except BotoCoreError as e:
        # BotoCoreError: Network issue or configuration problem
        print(f"[S3] Upload failed — BotoCoreError: {e}")
        raise RuntimeError(f"S3 connection failed: {e}") from e


def get_s3_presigned_url(s3_key: str, expiry_seconds: int = 3600) -> str:
    """
    Generate a temporary, pre-signed URL to access a private S3 file.
    
    WHY PRE-SIGNED URLS?
    S3 objects can be private (not publicly accessible). A pre-signed URL
    lets you share a file for a limited time without changing its permissions.
    
    Use case: Let a user download their PDF for 1 hour, then the link expires.
    
    Args:
        s3_key: The object's key in S3
        expiry_seconds: How long the URL stays valid (default: 1 hour)
    
    Returns:
        Temporary URL that expires after expiry_seconds
    """
    s3_client = boto3.client("s3", region_name=Config.AWS_REGION)
    url = s3_client.generate_presigned_url(
        "get_object",
        Params={"Bucket": Config.S3_BUCKET_NAME, "Key": s3_key},
        ExpiresIn=expiry_seconds,
    )
    return url


# ─────────────────────────────────────────────────────────────────────────────
# Amazon Bedrock Functions
# ─────────────────────────────────────────────────────────────────────────────

def _call_bedrock(prompt: str, max_tokens: int = 1000) -> str:
    """
    Internal helper: send a prompt to Amazon Bedrock and get text back.
    
    WHAT IS AMAZON BEDROCK?
    Bedrock is AWS's managed AI service that gives you access to foundation
    models (large language models) without managing any AI infrastructure.
    
    HOW IT WORKS:
    1. You call bedrock-runtime API with a prompt
    2. AWS sends your text to the model (Claude, Titan, etc.)
    3. Model returns generated text
    4. You get the response back
    
    Supported models include:
      - anthropic.claude-3-haiku-20240307-v1:0  (fast, cheap)
      - anthropic.claude-3-sonnet-20240229-v1:0  (smarter, more expensive)
      - amazon.titan-text-express-v1             (Amazon's own model)
    
    COST: ~$0.00025 per 1000 input tokens (Claude Haiku)
    A typical PDF summary costs less than $0.001
    
    Args:
        prompt: The instruction + text to send to the AI
        max_tokens: Maximum length of the response (1 token ≈ 0.75 words)
    
    Returns:
        The AI's text response
    """
    bedrock_client = boto3.client("bedrock-runtime", region_name=Config.AWS_REGION)

    # Bedrock request format for Claude models (Anthropic Messages API)
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": max_tokens,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    # invoke_model() sends the request to Bedrock
    # The response body is a StreamingBody that we read and parse as JSON
    response = bedrock_client.invoke_model(
        modelId=Config.BEDROCK_MODEL_ID,
        body=json.dumps(request_body),
        contentType="application/json",
        accept="application/json",
    )

    # Parse the response
    response_body = json.loads(response["body"].read())
    # Claude response structure: {"content": [{"type": "text", "text": "..."}]}
    return response_body["content"][0]["text"]


def _call_openai_fallback(prompt: str, max_tokens: int = 1000, json_mode: bool = False) -> str:
    """
    Fallback: use OpenAI if Bedrock is not configured.
    Set AI_PROVIDER=openai in your environment to use this.
    
    This is identical in outcome to Bedrock — same prompts, same results.
    Useful when you're learning and haven't set up AWS yet.
    """
    from openai import OpenAI
    client = OpenAI(api_key=Config.OPENAI_API_KEY)

    kwargs = {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": 0.4,
    }
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    response = client.chat.completions.create(**kwargs)
    return response.choices[0].message.content.strip()


def _ai_call(prompt: str, max_tokens: int = 1000, json_mode: bool = False) -> str:
    """Route AI call to Bedrock or OpenAI based on config."""
    if Config.AI_PROVIDER == "bedrock":
        return _call_bedrock(prompt, max_tokens)
    else:
        return _call_openai_fallback(prompt, max_tokens, json_mode)


def generate_summary_bedrock(text: str) -> str:
    """
    Use Amazon Bedrock (or OpenAI) to generate a concise study summary.
    
    PROMPT ENGINEERING:
    The prompt is the instruction we give the AI. Good prompts have:
    1. A clear role ("You are a study assistant")
    2. A specific task ("Summarize the following")
    3. Output constraints ("3-5 paragraphs", "simple language")
    4. The actual content (the extracted PDF text)
    
    WHY TRUNCATE TEXT?
    LLMs have a "context window" — max tokens they can process at once.
    Claude Haiku: 200K tokens, GPT-4o-mini: 128K tokens.
    We truncate to ~4000 words to keep costs low and responses fast.
    
    Args:
        text: The extracted text from the PDF
    
    Returns:
        AI-generated summary string
    """
    # Limit to ~4000 words to save on API costs
    words = text.split()
    truncated = " ".join(words[:4000])

    prompt = f"""You are a study assistant helping a student understand their academic notes.

Please provide a concise, clear summary of the following notes in 3-5 paragraphs.
- Use simple, accessible language
- Highlight the most important concepts
- Organize ideas logically
- Make it easy for a student to review before an exam

Notes to summarize:
{truncated}

Summary:"""

    try:
        return _ai_call(prompt, max_tokens=800)
    except Exception as e:
        print(f"[AI] Summary generation failed: {e}")
        raise RuntimeError(f"Summary generation failed: {str(e)}") from e


def generate_quiz_bedrock(text: str) -> list:
    """
    Use Amazon Bedrock (or OpenAI) to generate 10 multiple-choice questions.
    
    JSON MODE:
    We ask the AI to return structured JSON so we can parse it reliably.
    Without JSON mode, the AI might add prose around the JSON, breaking
    our json.loads() call.
    
    PROMPT STRUCTURE FOR QUIZ:
    - Tell AI what format to use (JSON schema)
    - Ask for exactly 10 questions
    - Specify 4 options per question
    - Require explanations (helps students learn from mistakes)
    
    Args:
        text: The extracted text from the PDF
    
    Returns:
        List of question dicts:
        [
          {
            "question": "What is X?",
            "options": ["A text", "B text", "C text", "D text"],
            "correct_index": 2,
            "explanation": "Because..."
          },
          ...
        ]
    """
    words = text.split()
    truncated = " ".join(words[:4000])

    prompt = f"""You are a quiz generator for students. Based on the provided study notes,
generate exactly 10 multiple-choice questions to test understanding.

Return ONLY valid JSON in this exact format, no other text:
{{
  "questions": [
    {{
      "question": "The question text here?",
      "options": ["Option A text", "Option B text", "Option C text", "Option D text"],
      "correct_index": 0,
      "explanation": "Brief explanation of why this answer is correct"
    }}
  ]
}}

Rules:
- correct_index is 0-based (0=A, 1=B, 2=C, 3=D)
- Each question must have exactly 4 options
- Make questions that test understanding, not just memorization
- Vary the difficulty (easy, medium, hard)
- Explanations should be 1-2 sentences

Study notes:
{truncated}"""

    try:
        raw = _ai_call(prompt, max_tokens=2500, json_mode=True)
        data = json.loads(raw)
        questions = data.get("questions", [])[:10]
        return questions
    except json.JSONDecodeError as e:
        print(f"[AI] Quiz JSON parse failed: {e}\nRaw response: {raw[:200]}")
        raise RuntimeError("AI returned invalid quiz format") from e
    except Exception as e:
        print(f"[AI] Quiz generation failed: {e}")
        raise RuntimeError(f"Quiz generation failed: {str(e)}") from e


# ─────────────────────────────────────────────────────────────────────────────
# AWS Lambda Invocation (Optional Pattern)
# ─────────────────────────────────────────────────────────────────────────────

def invoke_lambda_processor(doc_id: int, s3_key: str) -> dict:
    """
    Invoke an AWS Lambda function to process a PDF asynchronously.
    
    WHY LAMBDA FOR PROCESSING?
    PDF processing (text extraction + AI generation) can take 30-60 seconds.
    If this runs inside the Flask request, the user waits 60 seconds staring
    at a loading screen. That's a bad experience.
    
    Instead:
    1. Flask uploads PDF to S3 and saves a "pending" record to DB
    2. Flask returns immediately with "Processing..." to the user
    3. Lambda function processes it in the background (async)
    4. Lambda updates the DB record when done
    5. Frontend polls /status endpoint every 2 seconds until "done"
    
    This is the standard pattern for long-running tasks in web apps.
    
    Lambda function code would be in: lambda_function/handler.py
    
    COST: Lambda is priced per invocation + duration.
    Processing 100 PDFs/day costs ~$0.01. Extremely cheap.
    
    Args:
        doc_id: Database ID of the document record
        s3_key: S3 key where the PDF is stored
    
    Returns:
        Lambda invocation response dict
    """
    lambda_client = boto3.client("lambda", region_name=Config.AWS_REGION)

    # Payload sent to the Lambda function
    payload = {
        "doc_id": doc_id,
        "s3_key": s3_key,
        "bucket": Config.S3_BUCKET_NAME,
    }

    response = lambda_client.invoke(
        FunctionName=Config.LAMBDA_FUNCTION_NAME,
        # InvocationType="Event" = async (fire and forget)
        # InvocationType="RequestResponse" = sync (wait for result)
        InvocationType="Event",
        Payload=json.dumps(payload),
    )

    return {
        "status_code": response["StatusCode"],
        "request_id": response["ResponseMetadata"]["RequestId"],
    }
