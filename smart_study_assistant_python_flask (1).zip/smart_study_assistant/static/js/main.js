/* main.js — Global JavaScript for Smart Study Assistant */
/* (Most logic is inline in templates for clarity in learning) */
console.log("[Smart Study] App loaded.");
