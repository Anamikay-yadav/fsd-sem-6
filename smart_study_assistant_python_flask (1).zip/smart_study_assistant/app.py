"""
Smart Study Assistant - Flask Application
==========================================
CONCEPT: This is a web app where students upload PDF notes and receive:
  1. An AI-generated summary
  2. 10 multiple-choice quiz questions

WHAT IS FLASK?
Flask is a lightweight Python web framework. It handles:
  - URL routing (deciding what code runs when you visit a URL)
  - HTTP requests and responses
  - HTML template rendering

WHY FLASK? It's beginner-friendly, minimal setup, widely used in industry,
and perfect for connecting a Python backend to AWS services.

FOLDER STRUCTURE:
  smart_study_assistant/
  ├── app.py              ← You are here (main Flask application)
  ├── config.py           ← AWS & app configuration
  ├── aws_services.py     ← S3 and Bedrock helper functions
  ├── pdf_processor.py    ← PDF text extraction
  ├── database.py         ← SQLite database (swap for RDS in production)
  ├── templates/
  │   ├── base.html       ← Shared HTML layout
  │   ├── index.html      ← Dashboard/home page
  │   ├── upload.html     ← PDF upload form
  │   └── document.html   ← Summary + quiz display
  ├── static/
  │   ├── css/style.css   ← App styles
  │   └── js/main.js      ← Frontend JS for quiz interactions
  ├── requirements.txt    ← Python package list
  └── README.md           ← Setup instructions

FLASK ROUTE EXPLANATION:
  @app.route("/")         ← URL pattern
  def index():            ← Function that runs for that URL
      return "Hello"      ← What the browser receives

Every route function must return a Response (string, HTML, or JSON).
"""

import os
import uuid
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from werkzeug.utils import secure_filename

from config import Config
from aws_services import upload_to_s3, generate_summary_bedrock, generate_quiz_bedrock
from pdf_processor import extract_text_from_pdf
from database import init_db, save_document, get_all_documents, get_document, save_quiz_questions, get_quiz_questions, save_attempt, get_stats

# ─────────────────────────────────────────────────────────────────────────────
# Create and configure the Flask app
# app = Flask(__name__) creates the Flask application
# __name__ tells Flask where to find templates and static files
# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config.from_object(Config)

# Create upload folder if it doesn't exist
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize database tables on startup
with app.app_context():
    init_db()


def allowed_file(filename):
    """
    Check if uploaded file has an allowed extension.
    
    WHY THIS MATTERS: We only want PDF files. Without this check,
    someone could upload .exe or .sh files — a security risk.
    
    Example:
        allowed_file("notes.pdf")  → True
        allowed_file("virus.exe")  → False
    """
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]
    )


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE 1: Dashboard (Home Page)
# URL: http://localhost:5000/
# HTTP Method: GET (browser just reads the page)
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    """
    Show the dashboard with all uploaded documents and stats.
    
    render_template() fills in the HTML template with Python data.
    Think of templates like Mad Libs — the HTML has blank spaces
    that Python fills in with real data.
    """
    documents = get_all_documents()
    stats = get_stats()
    return render_template("index.html", documents=documents, stats=stats)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE 2: Upload Page
# URL: http://localhost:5000/upload
# HTTP Methods: GET (show the form) and POST (handle the submitted form)
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/upload", methods=["GET", "POST"])
def upload():
    """
    GET:  Show the upload form (empty page with a file picker)
    POST: Handle the uploaded file — extract text, call AI, save to DB
    
    WHY TWO METHODS? When a form is submitted, browsers use POST to
    send data to the server. GET just retrieves a page.
    """
    if request.method == "POST":
        # ── Step 1: Validate the uploaded file ──────────────────────────────
        # request.files contains uploaded files from the HTML form
        # The key "file" must match the name="" attribute in your HTML form
        if "file" not in request.files:
            flash("No file selected", "error")
            return redirect(request.url)

        file = request.files["file"]

        # An empty filename means no file was chosen
        if file.filename == "":
            flash("No file selected", "error")
            return redirect(request.url)

        if not allowed_file(file.filename):
            flash("Only PDF files are allowed", "error")
            return redirect(request.url)

        # ── Step 2: Save file locally with a safe, unique filename ───────────
        # secure_filename() prevents path traversal attacks like "../../etc/passwd"
        original_name = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{original_name}"
        local_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_filename)
        file.save(local_path)

        try:
            # ── Step 3: Upload PDF to Amazon S3 ─────────────────────────────
            # S3 = Amazon Simple Storage Service
            # Think of it like Google Drive — but for your app's files
            # We store PDFs here so they're durable and accessible to Lambda
            s3_key = f"uploads/{unique_filename}"
            s3_url = upload_to_s3(local_path, s3_key)

            # ── Step 4: Extract text from the PDF ───────────────────────────
            # PDFs aren't plain text — we use pdfplumber to read the content
            extracted_text = extract_text_from_pdf(local_path)

            if not extracted_text or len(extracted_text.strip()) < 50:
                flash("Could not extract text. Make sure PDF is not scanned/image-only.", "error")
                return redirect(request.url)

            # ── Step 5: Generate summary using Amazon Bedrock ────────────────
            # Bedrock is AWS's managed AI service. We use Claude or Titan
            # to generate a human-readable summary of the notes.
            summary = generate_summary_bedrock(extracted_text)

            # ── Step 6: Generate 10 quiz questions using Amazon Bedrock ──────
            quiz_questions = generate_quiz_bedrock(extracted_text)

            # ── Step 7: Save everything to the database ──────────────────────
            doc_id = save_document(
                filename=unique_filename,
                original_name=original_name,
                s3_url=s3_url,
                page_count=None,  # pdf_processor can populate this
                summary=summary,
                extracted_text=extracted_text,
            )

            save_quiz_questions(doc_id, quiz_questions)

            flash("Document processed successfully!", "success")
            return redirect(url_for("document_detail", doc_id=doc_id))

        except Exception as e:
            flash(f"Processing failed: {str(e)}", "error")
            return redirect(request.url)
        finally:
            # Clean up the local temp file (we already have it in S3)
            if os.path.exists(local_path):
                os.remove(local_path)

    # GET request — just show the empty upload form
    return render_template("upload.html")


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE 3: Document Detail
# URL: http://localhost:5000/document/5   (where 5 is the document ID)
# <int:doc_id> is a URL variable — Flask extracts the number automatically
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/document/<int:doc_id>")
def document_detail(doc_id):
    """
    Show the summary and quiz for a specific document.
    
    URL variables like <int:doc_id> are dynamic — they let one route
    handle /document/1, /document/2, /document/42, etc.
    """
    doc = get_document(doc_id)
    if not doc:
        flash("Document not found", "error")
        return redirect(url_for("index"))

    questions = get_quiz_questions(doc_id)
    return render_template("document.html", document=doc, questions=questions)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE 4: Submit Quiz Answer (JSON API endpoint)
# URL: http://localhost:5000/api/answer
# HTTP Method: POST (sends JSON data, gets JSON back)
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/answer", methods=["POST"])
def submit_answer():
    """
    Accept a quiz answer via AJAX (JavaScript fetch) and return
    whether it was correct, along with an explanation.
    
    This is an API endpoint — it speaks JSON, not HTML.
    The frontend JavaScript calls this without reloading the page.
    
    REQUEST body (JSON):
        { "question_id": 3, "selected_index": 2, "doc_id": 1 }
    
    RESPONSE body (JSON):
        { "correct": true, "correct_index": 2, "explanation": "..." }
    """
    data = request.get_json()

    if not data:
        return jsonify({"error": "No data provided"}), 400

    question_id = data.get("question_id")
    selected_index = data.get("selected_index")
    doc_id = data.get("doc_id")

    if question_id is None or selected_index is None:
        return jsonify({"error": "Missing question_id or selected_index"}), 400

    # Get question from DB to check the correct answer
    from database import get_question_by_id
    question = get_question_by_id(question_id)

    if not question:
        return jsonify({"error": "Question not found"}), 404

    is_correct = selected_index == question["correct_index"]

    # Record the attempt for scoring/stats
    save_attempt(doc_id=doc_id, question_id=question_id,
                 selected_index=selected_index, is_correct=is_correct)

    return jsonify({
        "correct": is_correct,
        "correct_index": question["correct_index"],
        "explanation": question.get("explanation", ""),
    })


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE 5: Delete a Document
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/document/<int:doc_id>/delete", methods=["POST"])
def delete_document(doc_id):
    """Delete a document and its associated quiz questions."""
    from database import delete_document_db
    delete_document_db(doc_id)
    flash("Document deleted", "success")
    return redirect(url_for("index"))


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# This block only runs when you execute: python app.py
# (Not when imported as a module — important for testing)
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # debug=True: auto-reloads on code change, shows detailed error pages
    # NEVER use debug=True in production — it exposes your source code!
    app.run(debug=True, host="0.0.0.0", port=5000)
