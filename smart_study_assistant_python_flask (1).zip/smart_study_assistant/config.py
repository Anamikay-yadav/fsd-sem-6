"""
Configuration Module
====================
CONCEPT: Centralize all settings in one place.
Instead of scattering "us-east-1" and bucket names across every file,
we define them here and import Config wherever needed.

WHY ENVIRONMENT VARIABLES?
Hardcoding secrets (API keys, passwords) in code is dangerous because:
  1. They get accidentally committed to Git
  2. Anyone who reads your code sees them
  3. You'd need code changes to update them

Environment variables are set on the server/machine, not in code.
  os.environ.get("KEY", "default") reads the variable if set,
  or uses "default" as a fallback.

HOW TO SET THEM LOCALLY:
  export AWS_REGION=us-east-1
  export S3_BUCKET_NAME=my-study-bucket
  python app.py

IN PRODUCTION (Lambda / EC2):
  Set them in the AWS console or via CloudFormation.
"""

import os


class Config:
    # ── Flask Settings ───────────────────────────────────────────────────────
    # SECRET_KEY: Used to sign session cookies (prevents tampering)
    # In production, use a long random string: python -c "import secrets; print(secrets.token_hex())"
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-in-production")

    # Upload folder for temporary local file storage before S3 upload
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", "/tmp/smart_study_uploads")

    # Only allow PDF uploads
    ALLOWED_EXTENSIONS = {"pdf"}

    # Maximum file size: 20 MB (20 * 1024 * 1024 bytes)
    MAX_CONTENT_LENGTH = 20 * 1024 * 1024

    # ── Database Settings ────────────────────────────────────────────────────
    # SQLite for development (file-based, no server needed)
    # Swap DATABASE_URL with your RDS PostgreSQL URL for production:
    #   postgresql://user:password@host:5432/dbname
    DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///smart_study.db")
    DATABASE_FILE = "smart_study.db"  # SQLite file path

    # ── AWS Settings ─────────────────────────────────────────────────────────
    # AWS_REGION: Which AWS data center to use
    AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

    # S3_BUCKET_NAME: Your S3 bucket where PDFs are stored
    # You must create this bucket in the AWS console first
    S3_BUCKET_NAME = os.environ.get("S3_BUCKET_NAME", "smart-study-assistant-pdfs")

    # ── Amazon Bedrock Settings ──────────────────────────────────────────────
    # Bedrock is AWS's managed AI service.
    # We use Anthropic's Claude model (available through Bedrock)
    # Alternative: Amazon Titan Text G1 - Express
    #   Model ID: "amazon.titan-text-express-v1"
    BEDROCK_MODEL_ID = os.environ.get(
        "BEDROCK_MODEL_ID",
        "anthropic.claude-3-haiku-20240307-v1:0"  # Fast + cheap Claude model
    )

    # ── AWS Lambda Settings (optional — for async processing) ────────────────
    # If you want to offload PDF processing to Lambda:
    LAMBDA_FUNCTION_NAME = os.environ.get("LAMBDA_FUNCTION_NAME", "smart-study-processor")

    # ── OpenAI Fallback (if Bedrock is not set up yet) ───────────────────────
    # Set OPENAI_API_KEY as an environment variable if using OpenAI instead
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

    # Which AI provider to use: "bedrock" or "openai"
    AI_PROVIDER = os.environ.get("AI_PROVIDER", "openai")  # default to openai for easy start
