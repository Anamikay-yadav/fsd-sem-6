"""
Database Module
===============
CONCEPT: Store document metadata, summaries, quiz questions, and attempts.

WHAT IS SQLite?
SQLite is a serverless database stored in a single file (smart_study.db).
- No installation required — Python has it built-in (import sqlite3)
- Perfect for development and small apps
- For production with multiple users, use PostgreSQL (Amazon RDS)

DATABASE TABLES:
  documents      — metadata for each uploaded PDF
  quiz_questions — 10 questions per document
  quiz_attempts  — tracks each time a user answers a question

WHY A DATABASE INSTEAD OF FILES?
If we stored summaries in .txt files, finding them quickly would be slow.
A database uses an index — like a book's index — so lookups are instant
even with millions of rows.

SQLITE VS POSTGRESQL (for your AWS deployment):
  SQLite:
    - File on disk, no server
    - Perfect for 1 user / development
    - Limitation: can't handle concurrent writes well

  Amazon RDS PostgreSQL:
    - Managed cloud database
    - Handles thousands of concurrent users
    - Automatic backups, scaling, patching
    - Cost: ~$15/month for dev-size instance (db.t3.micro)
    
TO SWITCH TO RDS: Change DATABASE_FILE to use psycopg2 driver and
replace sqlite3 with psycopg2.connect(DATABASE_URL)

SQL CRASH COURSE:
  CREATE TABLE  → define a new table
  INSERT INTO   → add a new row
  SELECT        → read rows
  UPDATE        → modify existing rows
  DELETE        → remove rows
  WHERE         → filter rows (like Python's if statement)
  JOIN          → combine data from two tables
"""

import sqlite3
from datetime import datetime
from config import Config


def get_db_connection():
    """
    Open a connection to the SQLite database.
    
    sqlite3.connect() opens the file (creates it if it doesn't exist).
    row_factory = sqlite3.Row makes rows behave like dicts:
      row["column_name"] instead of row[0]
    
    IMPORTANT: Always close the connection when done.
    Use "with" statement or call conn.close() explicitly.
    """
    conn = sqlite3.connect(Config.DATABASE_FILE)
    conn.row_factory = sqlite3.Row  # Access columns by name, not index
    conn.execute("PRAGMA foreign_keys = ON")  # Enforce foreign key constraints
    return conn


def init_db():
    """
    Create all database tables if they don't exist.
    
    Called once when the app starts.
    IF NOT EXISTS means it's safe to call multiple times — it won't
    wipe your data if the tables already exist.
    
    TABLE DESIGN EXPLANATION:
    
    documents table:
      - id: Auto-incrementing unique identifier (primary key)
      - filename: Stored filename (UUID + original name)
      - original_name: What the user uploaded (for display)
      - s3_url: Where the PDF lives in S3
      - status: Current state (pending/processing/done/error)
      - summary: AI-generated text summary
      - extracted_text: Raw PDF text (used to generate quiz)
      - created_at: Timestamp for sorting (newest first)
    
    quiz_questions table:
      - document_id: Links to documents.id (foreign key)
      - FOREIGN KEY + CASCADE: Auto-deletes questions when document is deleted
    
    quiz_attempts table:
      - Tracks every answer a user gives
      - Used to calculate average score
    """
    conn = get_db_connection()

    conn.executescript("""
        -- Documents table: one row per uploaded PDF
        CREATE TABLE IF NOT EXISTS documents (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            filename     TEXT    NOT NULL,
            original_name TEXT   NOT NULL,
            s3_url       TEXT    DEFAULT '',
            status       TEXT    NOT NULL DEFAULT 'done',
            page_count   INTEGER,
            summary      TEXT,
            extracted_text TEXT,
            error_message TEXT,
            created_at   TEXT    NOT NULL
        );

        -- Quiz questions: 10 per document
        CREATE TABLE IF NOT EXISTS quiz_questions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id   INTEGER NOT NULL,
            question      TEXT    NOT NULL,
            option_a      TEXT    NOT NULL,
            option_b      TEXT    NOT NULL,
            option_c      TEXT    NOT NULL,
            option_d      TEXT    NOT NULL,
            correct_index INTEGER NOT NULL,
            explanation   TEXT,
            order_index   INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
        );

        -- User quiz attempts: one row per answered question
        CREATE TABLE IF NOT EXISTS quiz_attempts (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id    INTEGER NOT NULL,
            question_id    INTEGER NOT NULL,
            selected_index INTEGER NOT NULL,
            is_correct     INTEGER NOT NULL,
            answered_at    TEXT    NOT NULL,
            FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
        );
    """)

    conn.commit()
    conn.close()


def save_document(filename, original_name, s3_url, page_count, summary, extracted_text) -> int:
    """
    Save a new document record to the database.
    
    Returns the auto-generated id of the new row.
    We use this id to associate quiz questions with this document.
    
    SQL INSERT explanation:
      INSERT INTO table (col1, col2) VALUES (?, ?)
      The ? placeholders prevent SQL injection attacks.
      Never use f-strings for SQL: f"INSERT ... VALUES ({user_input})"
      — that allows attackers to manipulate the query.
    """
    conn = get_db_connection()
    cursor = conn.execute(
        """
        INSERT INTO documents
            (filename, original_name, s3_url, page_count, summary, extracted_text, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'done', ?)
        """,
        (filename, original_name, s3_url, page_count, summary, extracted_text,
         datetime.now().isoformat()),
    )
    doc_id = cursor.lastrowid  # The auto-generated primary key
    conn.commit()
    conn.close()
    return doc_id


def save_quiz_questions(document_id: int, questions: list) -> None:
    """
    Save a list of quiz question dicts to the database.
    
    Each question dict comes from the AI response and looks like:
    {
        "question": "What is X?",
        "options": ["A text", "B text", "C text", "D text"],
        "correct_index": 2,
        "explanation": "Because..."
    }
    
    executemany() efficiently inserts multiple rows in one call.
    """
    if not questions:
        return

    conn = get_db_connection()
    rows = []

    for idx, q in enumerate(questions):
        options = q.get("options", ["", "", "", ""])
        # Pad options to 4 if AI returned fewer
        while len(options) < 4:
            options.append("")

        rows.append((
            document_id,
            q.get("question", ""),
            options[0], options[1], options[2], options[3],
            q.get("correct_index", 0),
            q.get("explanation", ""),
            idx,  # order_index for consistent display order
        ))

    conn.executemany(
        """
        INSERT INTO quiz_questions
            (document_id, question, option_a, option_b, option_c, option_d,
             correct_index, explanation, order_index)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        rows,
    )
    conn.commit()
    conn.close()


def get_all_documents() -> list:
    """
    Return all documents, newest first.
    
    ORDER BY created_at DESC = newest documents appear at the top.
    fetchall() returns all matching rows as a list.
    """
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT * FROM documents ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]  # Convert Row objects to regular dicts


def get_document(doc_id: int) -> dict | None:
    """
    Return a single document by ID.
    
    fetchone() returns one row, or None if no row matches.
    We use the WHERE clause to filter by primary key.
    """
    conn = get_db_connection()
    row = conn.execute(
        "SELECT * FROM documents WHERE id = ?", (doc_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_quiz_questions(document_id: int) -> list:
    """
    Return all quiz questions for a document, in order.
    
    We join the question options into a list for easy template rendering.
    """
    conn = get_db_connection()
    rows = conn.execute(
        """
        SELECT * FROM quiz_questions
        WHERE document_id = ?
        ORDER BY order_index
        """,
        (document_id,),
    ).fetchall()
    conn.close()

    questions = []
    for row in rows:
        q = dict(row)
        # Build the options list from individual columns
        q["options"] = [q["option_a"], q["option_b"], q["option_c"], q["option_d"]]
        questions.append(q)
    return questions


def get_question_by_id(question_id: int) -> dict | None:
    """Return a single quiz question by its ID."""
    conn = get_db_connection()
    row = conn.execute(
        "SELECT * FROM quiz_questions WHERE id = ?", (question_id,)
    ).fetchone()
    conn.close()
    if not row:
        return None
    q = dict(row)
    q["options"] = [q["option_a"], q["option_b"], q["option_c"], q["option_d"]]
    return q


def save_attempt(doc_id: int, question_id: int, selected_index: int, is_correct: bool) -> None:
    """Record a user's answer to a quiz question."""
    conn = get_db_connection()
    conn.execute(
        """
        INSERT INTO quiz_attempts
            (document_id, question_id, selected_index, is_correct, answered_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (doc_id, question_id, selected_index, 1 if is_correct else 0,
         datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()


def get_stats() -> dict:
    """
    Calculate dashboard statistics.
    
    AVG() = SQL aggregate function that calculates the average.
    COALESCE(x, 0) = return x if not null, otherwise return 0.
    This prevents the dashboard showing "None%" for average score.
    """
    conn = get_db_connection()

    total = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    total_quizzes = conn.execute("SELECT COUNT(*) FROM quiz_questions").fetchone()[0]
    avg_score = conn.execute(
        "SELECT COALESCE(AVG(is_correct) * 100, 0) FROM quiz_attempts"
    ).fetchone()[0]

    conn.close()

    return {
        "total_documents": total,
        "processed_documents": total,  # All documents are processed synchronously here
        "total_quizzes": total_quizzes,
        "average_score": round(avg_score, 1),
    }


def delete_document_db(doc_id: int) -> None:
    """
    Delete a document and all its associated data.
    
    Because we defined FOREIGN KEY ... ON DELETE CASCADE,
    SQLite automatically deletes related quiz_questions and quiz_attempts
    when we delete the parent document. No need for multiple DELETE statements.
    """
    conn = get_db_connection()
    conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    conn.commit()
    conn.close()
